# 2.0.5

- Potential Calendar bugfix

# 2.0.4

- Better TypeScript support (export interface ReactPickyDateTimeProps)

# 2.0.3

- Change animationInterval to 200 from 1000

# 2.0.2

- Support IE9+

# 2.0.1

- Fix markedDates not showing correctly bug

# 2.0.0

- Rewite with React Hooks
- Support TS
- Using https://gist.github.com/jakearchibald/cb03f15670817001b1157e62a076fe95 method to do the timer
- Not supporting IE anymore