import ReactPickyDateTime from './ReactPickyDateTime';
if (typeof window !== 'undefined') {
  (<any>window).ReactPickyDateTime = ReactPickyDateTime;
}

export default ReactPickyDateTime;
