var PickyDateTime = require('./lib/components/index.js').default;
require('./lib/react-picky-date-time.min.css');
module.exports = PickyDateTime;
